import { shallowMount } from '@vue/test-utils';

describe('HelloWorld.vue', () => {
    it('renders props.msg when passed', () => {
        expect(true).toBeTruthy();
    });
});
