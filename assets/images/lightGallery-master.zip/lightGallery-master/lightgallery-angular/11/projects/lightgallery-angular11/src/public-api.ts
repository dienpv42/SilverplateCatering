/*
 * Public API Surface of lightgallery-angular
 */

export * from './lib/lightgallery-angular.service';
export * from './lib/lightgallery-angular.component';
export * from './lib/lightgallery-angular.module';
