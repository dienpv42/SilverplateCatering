/*
 * Public API Surface of lightgallery-angular9
 */

export * from './lib/lightgallery-angular.service';
export * from './lib/lightgallery-angular.component';
export * from './lib/lightgallery-angular.module';
