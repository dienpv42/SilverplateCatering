---
title: Custom work
description: 'lightGallery custom modifications '
lead: One of the main benefits of using lightGallery is the ability to build galleries based on your unique requirements. It is easy to add new features or customize the existing functionalities.
date: 2020-10-06T08:48:57.000Z
draft: false
images: []
menu: {docs: {parent: API Docs}}
weight: 20
toc: true
---

If you need any help with customizing lightGallery, adding new features, create a new plugin, or need any other assistance that is beyond the scope of regular support, reach out to [contact@lightgalleryjs.com](mailto:contact@lightgalleryjs.com) with your requirements. We'll help you if we can or at least point you in the right direction.
